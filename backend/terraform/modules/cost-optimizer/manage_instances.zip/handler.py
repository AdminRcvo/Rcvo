import boto3
import os

def lambda_handler(event, context):
    ec2 = boto3.client('ec2')
    action = event.get('action')
    tags = event.get('tags', [])
    resp = ec2.describe_instances(Filters=[{'Name': 'tag:Name', 'Values': tags}])
    instance_ids = [i['InstanceId'] for r in resp['Reservations'] for i in r['Instances']]
    if action == 'stop':
        ec2.stop_instances(InstanceIds=instance_ids)
    elif action == 'start':
        ec2.start_instances(InstanceIds=instance_ids)
    return {'action': action, 'instances': instance_ids}
